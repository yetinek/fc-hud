const root = document.querySelector(".progbar");
const canvas = document.querySelector("canvas");
const textElement = document.querySelector("#progbar-text");
const ctx = canvas.getContext("2d");
let currentInterval = 0;
const colors = {
    bg: "#170A29",
    fg: "#8F5BD7",
}

function drawArch(W, H, ctx, from, to, color) {
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = W / 9.126;
    ctx.arc(W/2, H/2, W/2 - ctx.lineWidth/2, from, to, false);
    ctx.stroke();
}

function draw(percent) {
    const W = canvas.width;
    const H = canvas.height;

    ctx.clearRect(0, 0, W, H);
    drawArch(W,H,ctx,0, 2*Math.PI, `${colors.bg}7F`);
    const start = -Math.PI/2;
    drawArch(W,H,ctx, start, start + (2*Math.PI) * percent, colors.fg);

    const text = `${Math.round(percent*100)}%`;
    ctx.fillStyle = "white";
    ctx.font = "bold 2rem 'IBM Plex Sans', sans-serif"
    const textSize = ctx.measureText(text);
    const width = textSize.width;
    const height = textSize.actualBoundingBoxAscent;
    ctx.fillText(text, W / 2 - width / 2, H / 2 + height/2);
}

function init() {
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
}

window.onresize = init;

function runProgress(text, time) {
    if(currentInterval) {
        clearInterval(currentInterval);
    }

    textElement.innerText = text;
    const targetDate = new Date().getTime() + time;

    currentInterval = setInterval(() => {
        const now = new Date();
        const percent = 1 - (targetDate - now.getTime()) / time;
        console.log(percent)

        if(percent > 1) {
            clearInterval(currentInterval);
            currentInterval = 0;
            fetch(`https://fc-hud/progbar-finish`, {method: "POST", body: "{}"});
        }
        draw(percent);
    }, 1);
}

window.addEventListener("message", e => {
    const item = e.data;

    if(item.event === "startProgBar") {
        root.style.display = "flex";
        runProgress(item.text, item.time);
    }
})

//root.style.display = "none";
init();