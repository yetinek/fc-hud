fx_version "cerulean"
games {"gta5"}

ui_page "html/index.html";

lua54 "yes"
author 'hud by yeti czy cos takiego'

shared_script "@ox_lib/init.lua"

files {
    "minimap_border.png",
    "html/index.html",
    "html/css/*.css",
    "html/img/**/*.png",
    "html/img/**/*.svg",
    "html/img/**/*.jpg",
    "html/js/*.js",
    "html/sounds/**/*.mp3",
    "html/sounds/**/*.ogg",

    --Dui
    "dui/**/*.*",
}

files {
    'progbar.ytyp'
}

data_file 'DLC_ITYP_REQUEST' 'progbar.ytyp'

client_scripts {
    '@fc-core/client/lib.lua',
    'client/*.lua',
    'modules/*.client.lua',
}

server_scripts {
    'server/*.lua',
    'modules/*.server.lua',
}

-- sam se to podpinaj
-- client_script '@fc-loader/client/lib.lua'
-- server_script '@fc-loader/server/lib.lua'
-- my_data 'client_files' { 'client.lua' }