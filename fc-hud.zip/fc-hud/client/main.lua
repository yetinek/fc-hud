FocusedUIs = {}
SyncedEvents = {}
AwaitedMessages = {}
Scale = 1.0;
State = false
playerPed = PlayerPedId()

Citizen.CreateThread(function()
	State = true
end)

lib.onCache('ped', function(value) playerPed = value end)

AddEventHandler("fc-hud:getState", function(cb) cb(State) end)

AddEventHandler("fc-core:playerReady", function()
	SendNUIMessage({
		event = "setUserId",
		userId = Core.Player.id,
	});
end)

RegisterCommand("nuifix", function()
	TriggerEvent("fc-hud:nuiFix");
end)

AddEventHandler("fc-hud:nuiFix", function()
	for k,v in pairs(FocusedUIs) do
		unFocusUI(k);
	end
end)

function SendAppAction(app, action, payload)
	SendNUIMessage({
		event = "sendAppEvent",
		app = app,
		action = action,
		payload = payload,
	})
end

RegisterNUICallback("finishSyncEvent", function(data, cb)
	local key = data.event

	if(not SyncedEvents[key]) then return end
	SyncedEvents[key].finished = true
	SyncedEvents[key].state = data.state 
end)

RegisterNUICallback("sendAppMessage", function(data, cb)
	local key = data.event

	cb()
	if AwaitedMessages[key] then
		AwaitedMessages[key]:resolve(data.state)
	end
	AwaitedMessages[key] = nil
end)

function AwaitAppMessage(app, type)
	local key = app.."_"..type
	local prom = promise.new()
	AwaitedMessages[key] = prom

	return Citizen.Await(prom)
end

function SendSyncAppAction(app, action, payload, timeout)
	local key = app.."_"..action
	SyncedEvents[key] = {
		finished = false,
		state = nil,
	}

	SendNUIMessage({
		event = "sendAppEvent",
		app = app,
		action = action,
		payload = payload,
	})

	local timer = GetGameTimer()
	while not SyncedEvents[key].finished do
		Citizen.Wait(0)
		if timeout and timer - GetGameTimer > timeout then
			break
		end
	end

	local state = SyncedEvents[key].state
	SyncedEvents[key] = nil
	return state
end

function focusUI(uiName, cursor, keepInput)
	if cursor == nil then cursor = true end
	SetNuiFocus(true, cursor)
	SetNuiFocusKeepInput(keepInput)
	SendNUIMessage({
		event = "setFocused",
		name = uiName
	})
	FocusedUIs[uiName] = true
end

function unFocusUI(uiName)
	FocusedUIs[uiName] = nil
	if not next(FocusedUIs) then
		SetNuiFocus(false, false)
		SetNuiFocusKeepInput(false)
		SendNUIMessage({
			event = "setFocused",
			name = "",
		})
	else
		SendNUIMessage({
			event = "setFocused",
			name = next(FocusedUIs)
		})
	end
end

exports("RegisterHudCallback", function(name, callback)
	RegisterNUICallback(name, callback)
end)

exports("SendAppAction", SendAppAction)
exports("SendSyncAppAction", SendSyncAppAction)
exports("focusUI", focusUI)
exports("unFocusUI", unFocusUI)

RegisterNUICallback("hud:setScale", function(data, cb)
	Scale = data.scale;

	TriggerEvent("fc-hud:setScale", Scale);
	cb('ok');
end)

RegisterNUICallback("hud:setDot", function(data, cb)
	TriggerEvent("fc-base:crosshair", data.status);

	cb('ok');
end)

exports("getScale", function()
	return Scale;
end)