local state = false;
if GetCurrentResourceName() ~= "fc-hud" then
    Citizen.CreateThread(function()

        while state == false do 
            Citizen.Wait(0)
            TriggerEvent("fc-hud:getState", function(s) state = s end)
        end
    end)
end

function RegisterHudCallback(name, cb)
    Citizen.CreateThread(function()
        while not state do Citizen.Wait(0) end
        exports["fc-hud"]:RegisterHudCallback(name, cb);
    end)
end