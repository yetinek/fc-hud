local CurrentMenuId = 0
local CurrentOpenMenu = 0
local Menus = {}
local OpenMenus = {}

AddEventHandler("fc-hud:nuiFix", function()
    for k,v in pairs(OpenMenus) do
        closeMenu(v.id);
    end
end)

local function getMenuById(id)
    return Menus[id]
end

local function closeMenu(id)
    local closedId = nil
    for k,v in pairs(OpenMenus) do
        if v.id == id then
            Menus[v.id] = nil
            closedId = v.id
            table.remove(OpenMenus, k)
            break
        end
    end

    if closedId and closedId == CurrentOpenMenu then
        if next(OpenMenus) then
            setOpenMenu(OpenMenus[#OpenMenus].id)
        else
            unFocusUI("selectMenu")
            SendAppAction("selectMenu", "closeMenu")
            CurrentOpenMenu = 0
        end
    end
end

local function setOpenMenu(id)
    local menu = getMenuById(id)
    if not menu then
        print("tried to open non-existing menu")
        return
    end

    local payload = {}
    payload.title = menu.title
    payload.elements = menu.elements

    CurrentOpenMenu = id
    focusUI("selectMenu", true, false)
    SendAppAction("selectMenu", "openMenu", payload)
end

local function openSelectMenu(title, elements, callbacks)
    local self = {}
    CurrentMenuId = CurrentMenuId + 1

    self.id = CurrentMenuId
    self.title = title
    self.elements = elements
    self.callbacks = callbacks or {}

    self.close = function()
        closeMenu(self.id)

        if self.callbacks.close then
            self.callbacks.close(self)
        end
    end

    self.selected = function(element)
        if self.callbacks.selected then
            self.callbacks.selected(self, element)
        end
    end

    table.insert(OpenMenus, self)
    Menus[self.id] = self
    setOpenMenu(self.id)

    return self.id
end

RegisterNUICallback("selectMenu:closed", function(data, cb)
    if CurrentOpenMenu ~= 0 then
        getMenuById(CurrentOpenMenu).close()
    end
    cb({})
end)

RegisterNUICallback("selectMenu:submit", function(data, cb)
    if CurrentOpenMenu ~= 0 then
        getMenuById(CurrentOpenMenu).selected(data.el)
    end
    cb({})
end)

exports("openSelectMenu", openSelectMenu)

-- RegisterCommand("testuwaMenu", function()
--     local elements = {}

--     for i = 0, 10 do
--         table.insert(elements, {
--             value = "TESTUWA - "..i + CurrentMenuId,
--             title = "Tytułuwa - "..i + CurrentMenuId,
--             desc = "Opisuwa - "..i + CurrentMenuId
--         })
--     end

--     openSimMenu("Testowe menu", elements, {
--         close = function(menu)
--             print("CLOSED MENU", menu.id)
--         end,

--         selected = function(menu, element)
--             print(string.format("SELECTED [%s]: %s", menu.id, element.value))
--             menu.close()
--         end
--     })
-- end)