function startProgbar(text, time)
    return SendSyncAppAction("progbar", "runProgbar", {text = text, time = time})
end

function cancelProgbar()
    SendAppAction("progbar", "cancelProgbar")
end

exports("startProgbar", startProgbar)
exports("cancelProgbar", cancelProgbar)

RegisterNetEvent("fc-hud:progbar:startProgbar", function(text, time)
    startProgbar(text, time);
end)

AddEventHandler("fc-hud:nuiFix", function()
    -- cancelProgbar(); -- ! Nie wiem czy to dodawac
end)