RegisterNetEvent("fc-hud:notifications:add", function(title, opts)
    addNotification(title, opts);
end)

exports("addNotification", function(title, opts)
    addNotification(title, opts);
end)

function addNotification(title, opts)
    if not opts then opts = {} end;
    SendAppAction("notify", "addNotification", {
        aliveTime = opts.time or 5,
        title = title,
        desc = opts.desc,
    })
end

RegisterCommand('test', function ()
    exports['fc-hud']:addNotification('error')
end)

RegisterCommand('test2', function ()
    exports['fc-hud']:startProgbar('tekst', 1000)
end)