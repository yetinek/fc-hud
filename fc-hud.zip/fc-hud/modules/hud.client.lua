HudOpen = false;
local LoopRunning = false;
local hunger = 0;
local thirst = 0;
local stress = 0;
local playerId = PlayerId()
local currentRadio = 0;
local currentRadioCount = 0;
playerServerId = GetPlayerServerId(playerId)

Citizen.CreateThread(function()
    RegisterKeyMapping("+hud_show", "Pokaz/ukryj HUD", "MOUSE_BUTTON", "MOUSE_MIDDLE")
    SendAppAction("hud", "setVoice", {mode = 2, isTalking = false});
end)

AddEventHandler("pma-voice:setPlayerRadio", function(channel)
    currentRadio = channel;
    refreshRadio();
end)

AddEventHandler("pma-voice:radioCountChanged", function(count)
    currentRadioCount = count;
    refreshRadio();
end)

function refreshRadio()
    local radioString = currentRadio;
    if currentRadio ~= 0 then
        radioString = ("%s | %s"):format(currentRadio, currentRadioCount);
    end
    SendAppAction("hud", "setRadio", radioString);
end

RegisterCommand("+hud_show", function()
    ToggleHUD();
end);
RegisterCommand("-hud_show", function()end);

AddEventHandler('fc-core:playerReady', function()
    hunger = hunger
    thirst = thirst
    stress = stress
end)

RegisterNetEvent('fc-core:setPlayerValue', function(key, value)
    if(key == 'status') then
        hunger = hunger
        thirst = thirst
        stress = stress
    end
end)

AddEventHandler("fc-hud:playerTalking", function(mode, isTalking)
    SendAppAction("hud", "setVoice", {mode = mode, isTalking = isTalking});
end)

RegisterNetEvent('vSync:updateTime', function(base, offset)
    local timeOffset = offset
    local baseTime = base
    
    local time = {
        hour = math.floor(((baseTime+timeOffset)/60)%24),
        minutes = math.floor((baseTime+timeOffset)%60),
    }
    SendAppAction("hud", "setTime", time);
end)


local mask = false;
function getOxygen()
    local time = GetPlayerUnderwaterTimeRemaining(playerId)
    if time > 10 then
        mask = true
        return (time * 10) / 60
    elseif time <= 10 then
        if mask then
            local mask = false;
            return (time * 10) / 60
        else
            return (time * 10)
        end
    end
end

local isPlayerDead = false

function ToggleHUD()
    HudOpen = not HudOpen;

    SendAppAction("hud", "setVisible", {visible = HudOpen});

    if HudOpen and not LoopRunning then
        Citizen.CreateThread(function()
            local percentHP = GetEntityHealth(ped) / GetPedMaxHealth(ped) * 100
            LoopRunning = true;
            while HudOpen do
                local oxy = getOxygen();
                if oxy >= 100 then
                    oxy = 0;
                end

                local status = {
                    health = ((GetEntityHealth(playerPed) - 100) / (GetEntityMaxHealth(playerPed) - 100)) * 100,
                    armour = GetPedArmour(playerPed),
                    oxygen = oxy,
                    hunger = hunger,
                    thirst = thirst,
                    stress = stress,
                }

                if LocalPlayer.state.Dead then
                    status.health = 0;
                end

                SendAppAction("hud", "setStatus", status);
                Citizen.Wait(500);
            end
            LoopRunning = false;
        end)
    end
end

AddStateBagChangeHandler("Dead", ("player:%s"):format(playerServerId), function(bagName, key, value, reserved, replicated)
    isPlayerDead = value
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)
        TriggerEvent('esx_status:getStatus', 'hunger', function(status)
            hunger = status.val/1000000*100
        TriggerEvent('esx_status:getStatus', 'thirst', function(status)
            thirst = status.val/1000000*100
            TriggerEvent('esx_status:getStatus', 'drunk', function(status)
                najebany = status.val/1000000*100
                    TriggerEvent('esx_status:getStatus', 'stress', function(status)
                        stress = status.val/1000000*100
                    end)
                end)
            end)
        end)
    end
end)