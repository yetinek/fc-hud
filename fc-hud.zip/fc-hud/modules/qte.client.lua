function startQte(options)
    TriggerEvent('ox_inventory:closeInventory')
    LocalPlayer.state.InvBinds = false;
    focusUI("qte", false)
    local state = SendSyncAppAction("qte", "gameStart", options or {})
    unFocusUI("qte")
    LocalPlayer.state.InvBinds = true;
    return state
end

exports("startQte", startQte)