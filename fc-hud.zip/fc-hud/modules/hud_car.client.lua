local inVeh = false;
curVeh = nil;
curVehFuel = 0.0
local directions = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
local lastLoadedFuel = GetGameTimer() - 1000;
local loadedFuel = 0;
local hudCarVisible = true;
local isInvVisible = false;
IsPhoneOpen = false;
CameraOpened = false;

local fuelStateBagHandler = nil

Citizen.CreateThread(function()
    local txd = CreateRuntimeTxd("fc-hud");
    CreateRuntimeTextureFromImage(txd, "minimap_border", "minimap_border.png");

    RequestStreamedTextureDict("map", false)
    while not HasStreamedTextureDictLoaded("map") do
        Citizen.Wait(0)
    end
    AddReplaceTexture("platform:/textures/graphics", "radarmasksm", "map", "radarmasksm")
    SetBlipAlpha(GetNorthRadarBlip(), 0.0)
    SetBlipScale(GetMainPlayerBlipId(), 0.7)

    SetMinimapComponentPosition("minimap", "L", "B", 0.025-1.8*0.025, 0.00, 0.153, 0.24)
    SetMinimapComponentPosition("minimap_mask", "L", "B", 0.135-0.2*0.135, 0.12+0.2*0.12, 0.093, 0.164)
    SetMinimapComponentPosition("minimap_blur", "L", "B", 0.0216-1.8*0.0216, 0.0176+1.7*0.0176, 0.2304, 0.3033)

    SetMinimapClipType(1)
    DisplayRadar(0);
end)

lib.onCache('vehicle', function(value)
    if value then
        inVeh = true
        curVeh = value
        curVehFuel = Entity(curVeh).state.fuel
        SendAppAction("hud", "setInVeh", {visible = true})

        fuelStateBagHandler = AddStateBagChangeHandler("fuel", ("entity:%s"):format(NetworkGetNetworkIdFromEntity(curVeh)), function(bagName, key, value)
            curVehFuel = value
        end)

        startThread()
        DisplayRadar(1)
    else
        inVeh = false
        curVeh = nil
        curVehFuel = 0.0
        SendAppAction("hud", "setInVeh", {visible = false})

        if not fuelStateBagHandler then RemoveStateBagChangeHandler(fuelStateBagHandler) end

        if not IsPhoneOpen then
            DisplayRadar(0)
        end
    end
end)

function compass(heading)
    return directions[(math.floor((heading / 45) + 0.5) % 8) + 1];
end

function getFuel()
    -- if not curVeh then
    --     return 0
    -- end
    -- local now = GetGameTimer()
    -- if now - lastLoadedFuel > 1000 then
    --     lastLoadedFuel = GetGameTimer();
    --     local fuelLevel = Entity(curVeh).state.fuel;
    --     if fuelLevel then
    --         loadedFuel = fuelLevel
    --     end
    --     return tonumber(loadedFuel);
    -- else
    --     return loadedFuel; 
    -- end
    return curVehFuel
end

function startThread()
    local currentStreet = "";
    local waypointDist = 0;
    Citizen.CreateThread(function()
        while inVeh do
            local coords = GetEntityCoords(curVeh);
            currentStreet = GetStreetNameFromHashKey(GetStreetNameAtCoord(coords.x, coords.y, coords.z));
            
            if IsWaypointActive() then 
                local waypointCoords = GetBlipCoords(GetFirstBlipInfoId(8))
                waypointDist = CalculateTravelDistanceBetweenPoints(coords.x, coords.y, coords.z, waypointCoords.x, waypointCoords.y, waypointCoords.z) / 1000
            else
                waypointDist = 0;
            end
            Citizen.Wait(500);
        end
    end)

    Citizen.CreateThread(function()
        while inVeh do
            if HudOpen then
                local heading = 360.0 - ((GetGameplayCamRot(0).z + 360.0) % 360.0)

                local vehData = {
                    speed = math.floor(GetEntitySpeed(curVeh) * 2.236936),
                    street = currentStreet,
                    direction = compass(heading),
                    fuel = getFuel(), 
                    distToWaypoint = waypointDist
                }
                SendAppAction("hud", "setVehData", vehData);
                Citizen.Wait(100);
            else
                Citizen.Wait(1000);
            end
        end
    end)
end

local radarThread = false;
local _displayRadar = DisplayRadar;
function DisplayRadar(val)
    _displayRadar(val)

    if val and not radarThread then
        radarThread = true;
        Citizen.CreateThread(function()
            local mCoords = GetMinimapAnchor();
            local minimap = RequestScaleformMovie('minimap')
            SetRadarBigmapEnabled(true, false)
            Citizen.Wait(0)
            SetRadarBigmapEnabled(false, false)

            local scale = mCoords.width;
            local offsetX = -0.0065;
            local offsetY = -0.0247;
            local elipsisFactor = 0.04;
            local aspect_ratio = GetAspectRatio(1)

            while not IsRadarHidden() do
                Citizen.Wait(0);
                if hudCarVisible and not isInvVisible and not IsRadarHidden() and aspect_ratio < 2.3 and not CameraOpened then
                    DrawSprite(
                        "fc-hud", 
                        "minimap_border", 
                        (mCoords.left_x + mCoords.right_x)/2 + offsetX, 
                        (mCoords.top_y + mCoords.bottom_y)/2 + offsetY, 
                        scale + scale * elipsisFactor,
                        aspect_ratio * scale, 
                        0, 255, 255, 255, 255
                    ); 
                else
                    Citizen.Wait(300)
                end
            end

            radarThread = false;
        end)
    end
end
exports("DisplayRadar", DisplayRadar);

function GetMinimapAnchor()
    local safezone = GetSafeZoneSize()
    local safezone_x = 1.0 / 20.0
    local safezone_y = 1.0 / 20.0
    local aspect_ratio = GetAspectRatio(0)
    local res_x, res_y = GetActiveScreenResolution()
    local xscale = 1.0 / res_x
    local yscale = 1.0 / res_y
    local Minimap = {}
    Minimap.width = xscale * (res_x / (4 * aspect_ratio))
    Minimap.height = yscale * (res_y / 5.674)
    Minimap.left_x = xscale * (res_x * (safezone_x * ((math.abs(safezone - 1.0)) * 10)))
    Minimap.bottom_y = 1.0 - yscale * (res_y * (safezone_y * ((math.abs(safezone - 1.0)) * 10)))
    Minimap.right_x = Minimap.left_x + Minimap.width
    Minimap.top_y = Minimap.bottom_y - Minimap.height
    Minimap.x = Minimap.left_x
    Minimap.y = Minimap.top_y
    Minimap.xunit = xscale
    Minimap.yunit = yscale
    return Minimap
end

AddEventHandler("fc-hud:hudCarVisible", function(state)
    hudCarVisible = state
    DisplayRadar(hudCarVisible)
end)

AddStateBagChangeHandler("IsPhoneOpen", ("player:%s"):format(playerServerId), function(bagName, key, value, reserved, replicated)
    IsPhoneOpen = value
end)

AddStateBagChangeHandler("invOpen", ("player:%s"):format(playerServerId), function(bagName, key, value, reserved, replicated)
    isInvVisible = value
end)

AddStateBagChangeHandler("CameraOpened", ("player:%s"):format(playerServerId), function(bagName, key, value, reserved, replicated)
    CameraOpened = value
    if value then
        if IsPhoneOpen or inVeh then
            DisplayRadar(false)
        end
    else
        if IsPhoneOpen or inVeh then
            DisplayRadar(true)
        end
    end
end)