local OptionsOpen = false;

RegisterCommand("hud", function()
    focusUI("options");
    SendAppAction("options", "setVisible", true);
end)

RegisterNUICallback("options:closed", function(data, cb)
    unFocusUI("options");
    cb();
end)

AddEventHandler("fc-hud:nuiFix", function()
    SendAppAction("options", "setVisible", false);
end)