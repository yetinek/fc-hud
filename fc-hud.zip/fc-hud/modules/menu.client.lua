local CurrentMenuId = 0;
local CurrentOpenMenu = 0;
local Menus = {};
local OpenMenus = {};

Citizen.CreateThread(function()
    local MappingKeys = {"BACK", "UP", "DOWN", "ESCAPE", "RETURN"};

    for k,v in pairs(MappingKeys) do
        local key = v;
        if key == "BACK" then
            key = "ESCAPE"
        elseif key == "RETURN" then
            key = "ENTER"
        end
        RegisterKeyMapping("+hud_menu_"..v, "Menu-"..v, "KEYBOARD", v);
        RegisterCommand("+hud_menu_"..v, function()
            if(CurrentOpenMenu == 0) then return end;
            SendAppAction("menu", "keyPressed", string.lower(key));
        end);
        RegisterCommand("-hud_menu_"..v, function()end);
    end
end)

local function getMenuById(id)
    return Menus[id];
end

local function setOpenMenu(id)
    local menu = getMenuById(id);
    if not menu then
        print("tried to open non-existing menu")
        return;
    end

    local payload = {};
    payload.title = menu.title;
    payload.elements = menu.elements;
    payload.index = menu.currentIndex - 1;

    CurrentOpenMenu = id;
    SendAppAction("menu", "openMenu", payload);
end

local function closeMenu(id)
    local closedId = nil;
    for k,v in pairs(OpenMenus) do
        if v.id == id then
            Menus[v.id] = nil;
            closedId = v.id;
            table.remove(OpenMenus, k);
            break;
        end
    end

    if closedId and closedId == CurrentOpenMenu then
        if next(OpenMenus) then
            setOpenMenu(OpenMenus[#OpenMenus].id);
        else
            SendAppAction("menu", "closeMenu");
            CurrentOpenMenu = 0;
        end
    end
end

local function openMenu(title, elements, callbacks)
    local self = {};
    CurrentMenuId = CurrentMenuId + 1;

    self.id = CurrentMenuId;
    self.title = title;
    self.elements = elements;
    self.callbacks = callbacks or {};
    self.currentIndex = 1;

    self.close = function()
        closeMenu(self.id);

        if self.callbacks.close then
            self.callbacks.close(self);
        end
    end

    self.selected = function(element)
        if self.callbacks.selected then
            self.callbacks.selected(self, element);
        end
    end

    self.index = function(index)
        self.currentIndex = index;

        if self.callbacks.index then
            self.callbacks.selected(self, index);
        end
    end

    table.insert(OpenMenus, self);
    Menus[self.id] = self;
    setOpenMenu(self.id);

    return self.id;
end

RegisterNUICallback("menu:closed", function(data, cb)
    if CurrentOpenMenu ~= 0 then
        getMenuById(CurrentOpenMenu).close();
    end
    cb({});
end)

RegisterNUICallback("menu:submit", function(data, cb)
    if CurrentOpenMenu ~= 0 then
        getMenuById(CurrentOpenMenu).selected(data.el);
    end
    cb({});
end)

RegisterNUICallback("menu:index", function(data, cb)
    if CurrentOpenMenu ~= 0 then
        getMenuById(CurrentOpenMenu).index(data.index + 1);
    end
    cb({});
end)

-- RegisterCommand("testMenu", function()
--     local elements = {};

--     for i = 0, 10 do
--         table.insert(elements, {
--             value = "TESTUWA - "..i + CurrentMenuId,
--             title = "Tytułuwa - "..i + CurrentMenuId,
--             desc = "Opisuwa - "..i + CurrentMenuId
--         })
--     end

--     openMenu("Testowe menu", elements, {
--         close = function(menu)
--             print("CLOSED MENU", menu.id);
--         end,

--         selected = function(menu, element)
--             print(string.format("SELECTED [%s]: %s", menu.id, element.value))
--             menu.close();
--         end
--     })
-- end)

exports("openMenu", openMenu)

AddEventHandler("fc-hud:nuiFix", function()
    for k,v in pairs(OpenMenus) do
        closeMenu(v.id);
    end
end)