exports("CharacterSelect", function(characters)
    SendAppAction("characterSelect", "loadCharacters", characters)
    SendAppAction("characterSelect", "setVisible", true);
    focusUI("characterSelect", true);
    local character = AwaitAppMessage("characterSelect", "selected")
    return character
end)

exports("CharacterSuccess", function()
    unFocusUI("characterSelect");
    SendAppAction("characterSelect", "setVisible", false);
    SendAppAction("characterSelect", "openCreator", false);
end)

AddEventHandler("fc-hud:nuiFix", function()
    SendAppAction("characterSelect", "setVisible", false);
end)